# Gui.py
# Revision : 1.0
# Author   : Swapnil S. Bhujbal
# Email ID : Swapnil.bhujbal@luminartech.com
# 
#
# Revision History : 1.0 - Able to Link to Jama items with Downstream relationship and Get relationships , Note -Put button doenst work
#
###################################################################################################################
import pandas as pd
import PySimpleGUI as sg
from py_jama_rest_client.client import JamaClient

def Downlink(from_item,to_item):
   #sg.popup_error("In Downlink")
    print("From_item = ",from_item,end=' ') 
    print("To_item = ",to_item)
    #sg.popup(title="Downlin item to current jama item",custom_text=from_item)
    try:
        s = jama_client.post_relationship(from_item,to_item,4)  # COMMENT THIS LINE TO UNDERSTAND IF CORRECT COLUMN NO SELECTED
        print(s)
        print("Linked") 
    except:
        sg.popup(title="Error",custom_text="!! Downlink already exists !!")
        print("Link Already Exists")
   # add post rest api to link jama item
    
layout = [
    [sg.Text("Browse input requirment file:"),sg.Input(key="-IN-"),sg.FilesBrowse()],
    [sg.Text("Output Folder:"),sg.Input(key="-OUT-"),sg.FolderBrowse()],
    [sg.Text("Get Downstream Relationship ID:"),sg.Input(key="-IN-3"),sg.Button(" Get "),sg.Button(" Put ")],
    [sg.Text("Downstream linking")],
    [sg.Text("API_ID From:"),sg.Input(key="-IN-1")],
    [sg.Text("API_ID To:"),sg.Input(key="-IN-2"),sg.Button(" Link ")],
    [sg.Button("OK")]

]

margins=(100, 50)
#create a window
window = sg.Window("Luminar Jama Requirement Link",layout,margins)

# Create the JamaClient
jama_client = JamaClient('https://luminar.jamacloud.com', credentials=('kwxt2qcnup2eyky', 'w8knzuhhoqqmc1h1dc34gnnzn'), oauth=True)

#create a loop
while True:
    event, values = window.read()

    if event == sg.WIN_CLOSED:
        break
    if event == "Enter API ID From":  # can we do event for text
        sg.popup_error("Please enter correct ID")
    if event == "OK":
        print(values["-IN-1"])
        #Downlink(
        #    from_item=values["-IN-1"],
        #    to_item=values["-IN-2"]
        #    )
        window.close()
    if event == " Get ":
        print(values["-IN-3"])
        #Downstream
        Downrelationships = jama_client.get_items_downstream_related(values["-IN-3"],1)
        print(Downrelationships)
    if event == " Put ":
        print(values["-IN-3"])
        #Downstream
        Prelationships = jama_client.put_relationship(2015026,values["-IN-3"],values["-IN-2"],4)
        print(Prelationships)
    if event == " Link ":
        print("link started")
        Downlink(
            from_item=values["-IN-1"],
            to_item=values["-IN-2"]
            )
window.close()

#sg.Window(title="Jama GUI", layout=[[]], margins=(100, 50)).read()


